%% HW 2 Part 1 and 2
% Name: Dylan Kingsbury
% Purpose: To determine when to to drop a package from a plane
% Copyright 2017

clc; % clear command windows
clear; % clear all variables

% State any given information
g=9.81; % Gravity
mitome=0.44704; %conversion of MPH to m/s

% Prompt user to enter the constant horizontal velocity of the aircraft in MPH 
% and the altitude of the plane in meters (m).
Speed=[input('Enter the constant horizontal velocity of the aircraft in miles per hour: ')].*mitome;
Altitude=input('Enter the altitude of the aircraft in meters (m): ');

% Calculate the time it takes to reach sea level and the horizontal distance 
%from the plane to the island.
t=sqrt((2.*Altitude)./g);
Distance=Speed.*t;

% Calculate the angle, in degrees, that the island will be under the
% horizon of the pilots sight when it is time to make the drop.
DropAngle=atand(Altitude./Distance);

% Display the time it will take the package to fall to the island
fprintf('It will take ''%1.2f'' seconds for the package to land on the island!\n',t)

% Display the horizontal distance the package will travel to the island
fprintf('The package will travel ''%1.2f'' meters horizontally before landing on the island!\n',Distance)

% Display the angle the island makes with the horizon of the plane
fprintf('The island will be ''%1.1f'' degrees under your line-of-sight when it is ready to be dropped!\n',DropAngle)

% Compute the actual landing zone of food on island
LOS=input('Input the line-of-sight angle when the food was actually dropped: ');
Distance2=Altitude/tand(LOS);
Delta=Distance-Distance2;

% Display whe Delta and if the drop was successful!
fprintf('The Delta is ''%1.2f'' meters!\n',Delta)

if (-20<=Delta && Delta <=20)
    disp('The drop was successful!')
else
    disp('The drop landed in the sea!')
end

% Plotting the food drops

% Setting up the guidelines for the plot
axi=linspace(0,t,100);

% This is the plot for having dropped it at the perfect moment
Px=Speed.*axi;
Py=Altitude-.5.*g.*axi.^2;

% This is the plot for the actual line-of-sight angle drop
Ax=Delta+Speed.*axi;
Ay=Altitude-.5.*g.*axi.^2;

% Define the Cargo Plane
CargoPx=0;
CargoPy=Altitude;

CargoAx=Delta;
CargoAy=Altitude;

% Define the Island
Islandx=linspace(Distance-20,Distance+20,40);
Islandy=0;

% Define the axis parameters
xmin=min(Px);
xmax=max(Px);
ymin=min(Py);
ymax=max(Py);
axis([xmin,xmax,ymin,ymax]);

% Plot the required materials
plot(Px,Py,'g-.',Ax,Ay,'b-.',CargoPx,CargoPy,'g->',CargoAx,CargoAy,'b->',Islandx,Islandy,'y-o')

grid on

%Labels 
title('Air Drop Success Chart')
xlabel('Distance to Island')
ylabel('Altitude')

% Create a legend
legend('Perfect Drop','Actual Drop','Perfect Position','Actual Position','The Island')


