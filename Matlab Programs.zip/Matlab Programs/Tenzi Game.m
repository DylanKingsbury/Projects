% Name: Dylan Kingsbury
% Purpose: To creat an application capable of playing a one player version of Tenzi
% Copyright 2017

clc; % clear command window
clear; % clear all variables

% Shuffle the random number generator in the pc
rng('Shuffle');

% Setup roll calculator and display roll
Roll=randi(6,1,10);
fprintf('Roll    :');
fprintf('%6.0f',Roll);

% Prompt for the number the user wishes to keep on the side
Number=input('\nPlease enter the number you wish to keep on the side:   ');
while(Number<=0 || Number>6)
    fprintf('Please pick a number between 1 and 6!')
    Number=input('\nPlease enter the number you wish to keep on the side:   ');
end
% Determine how many to side and how to output the correct format
Side=0;
Checker=1;
while(Side<10)
    while(Checker<11-Side)
    if(Number==Roll(Checker))
        Side=Side+1;
        Checker=Checker+1;
    else
        Checker=Checker+1;
    end
    end
        Roll=randi(6,1,10-Side);
        Checker=1;
        Sidehelp=zeros(1,Side);
        SideCounter=Sidehelp+Number;
        fprintf('                   ***There are %1.0f dice on the side***',Side);
        fprintf('\nSide    :');
        fprintf('%6.0f',SideCounter);
        fprintf('\nNew Roll:');
        fprintf('%6.0f',Roll);
        fprintf('\n');
    if(Side==10)
        fprintf(1,'                              TENZI!!!\n'); % The game is over! TENZI!        
    end
end

% use mode function
