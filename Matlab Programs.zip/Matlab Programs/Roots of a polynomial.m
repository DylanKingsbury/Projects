%% HW 2 Part 1
% Name: Dylan Kingsbury
% Purpose: To find the roots of any second order polynomial equation
% Copyright 2017

clc % clear command windows
clear % clear all variables

% Prompt user to enter three real numbers for a, b and c. Note that a~=0.

a=input('Enter a non-zero real number for a: ')
b=input('Enter a real number for b: ')
c=input('Enter a real number for c: ')

% x1 output
x1=(-b+sqrt((b.^2)-4.*a.*c))/2.*a

% x2 output
x2=(-b-sqrt((b.^2)-4.*a.*c))/2.*a

% Display the answer to the question

disp(['The roots x1 and x2 are ',num2str(x1),' and ',num2str(x2),' respectively.'])

%% HW 1 Part 2
% Name: Dylan Kingsbury
% Purpose: To generate a conversion table of any length and increment to convert car speed in Miles per hour (MPH) to Kilometers per hour (km/h)
% Copyright 2017

clc % clear command windows
clear % clear all variables

% Prompt user to enter three real numbers for a, b and c. Note that a~=0.

StartingMPH=input('Enter the starting speed in MPH: ')
Increments=input('Enter the increment between the lines in MPH: ')
Numberoflines=input('Enter the number of lines in the table: ')

% Creat the vector array ConversionTable
ConversionTable=(StartingMPH:Increments:StartingMPH+Increments.*(Numberoflines-1))'

% Convert the MPH to km/H
kmConversion=(ConversionTable.*1.609344)

% Make a matrix for displaying
A=[ConversionTable;kmConversion]

% Display the Conversion Table
fprintf('     MPH     km/H\n-----------------------\n')
for n=(1:Numberoflines)
    fprintf('%8.2f %9.2f\n',ConversionTable(n), kmConversion(n))
end