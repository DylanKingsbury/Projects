function varargout = HW4Graph(varargin)
% HW4Graph MATLAB code for HW4Graph.fig
%      HW4Graph, by itself, creates a new HW4Graph or raises the existing
%      singleton*.
%
%      H = HW4Graph returns the handle to a new HW4Graph or the handle to
%      the existing singleton*.
%
%      HW4Graph('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HW4Graph.M with the given input arguments.
%
%      HW4Graph('Property','Value',...) creates a new HW4Graph or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before HW4Graph_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to HW4Graph_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help HW4Graph

% Last Modified by GUIDE v2.5 15-Oct-2017 14:17:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @HW4Graph_OpeningFcn, ...
                   'gui_OutputFcn',  @HW4Graph_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before HW4Graph is made visible.
function HW4Graph_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to HW4Graph (see VARARGIN)

% Choose default command line output for HW4Graph
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes HW4Graph wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% DO NOT MODIFY BEFORE THIS POINT! 000000000000000000000000000000000000000

axes(handles.axes3)
imshow('Flying.png')
axes(handles.axes4)
imshow('Island.jpg')


% --- Outputs from this function are returned to the command line.
function varargout = HW4Graph_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;




% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get slider value and save in s1
s1=round(get(hObject,'Value'),1);
% convert s1 to text
s1Text=num2str(round(s1,0),'%f');
% show s1Text in edit box 1
set(handles.edit1,'String',s1Text);

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get slider value and save in s2
s2=round(get(hObject,'Value'),1);
% convert s2 to text
s2Text=num2str(round(s2,0),'%f');
% show s2Text in edit box 2
set(handles.edit2,'String',s2Text);

% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get the text from Edit Box 1
e1Text=get(hObject,'String');
 % convert the e1Text to number
e1=round(str2num(e1Text),1);
% Set the Slider 1 value to e1
set(handles.slider1,'Value',e1);

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get the text from Edit Box 2
e2Text=get(hObject,'String');
 % convert the e2Text to number
e2=round(str2num(e2Text),1);
% Set the Slider 2 value to e2
set(handles.slider2,'Value',e2);

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in togglebutton4.
function togglebutton4_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% State any given information
g=9.81; % Gravity
mpm=0.44704; %conversion of MPH to m/s

% Prompt user to enter the constant horizontal velocity of the aircraft in MPH 
% and the altitude of the plane in meters (m).
mphspeed=str2num(get(handles.edit2,'String'));
Altitude=str2num(get(handles.edit1,'String'));
Speed=mpm.*mphspeed;

% Calculate the time it takes to reach sea level and the horizontal distance 
%from the plane to the island.
t=sqrt((2.*Altitude)./g);
Distance=Speed.*t;

% Calculate the angle, in degrees, that the island will be under the
% horizon of the pilots sight when it is time to make the drop.
DA=atand(Altitude./Distance);
DropAngle=round(DA,1);

% set text 12 to equal the DropAngle
set(handles.text12,'String',DropAngle);

% Plotting the food drops
axes(handles.axes1)
% Setting up the guidelines for the plot
axi=linspace(0,t,100);

Distance2=Altitude/tand(DropAngle);
Delta=Distance-Distance2;

% This is the plot for having dropped it at the perfect moment
Px=Speed.*axi;
Py=Altitude-.5.*g.*axi.^2;

% Define the Cargo Plane
CargoPx=0;
CargoPy=Altitude;

CargoAx=Delta;
CargoAy=Altitude;

% Define the Island
Islandx=linspace(Distance-20,Distance+20,40);
Islandy=0;

% Define the axis parameters
xmin=min(Px);
xmax=max(Px);
ymin=min(Py);
ymax=max(Py);
axis([xmin,xmax,ymin,ymax]);

% Plot the required materials
plot(Px,Py,'g-.',CargoPx,CargoPy,'g->',Islandx,Islandy,'y-o')

grid on

%Labels 
title('Air Drop Success Chart')
xlabel('Distance to Island')
ylabel('Altitude')

% Create a legend
legend('Perfect Drop','Perfect Position','The Island')

% set the angle counter 
x=0;
global button;
button=0;
while (button==0)
    set(handles.edit3,'String',x);
    pause(0.05);
    x=(x+0.1);
end

if (button==1)
% Replotting the food drops
axes(handles.axes1)

% Setting up the guidelines for the plot
axi=linspace(0,t,100);

Distance2=Altitude/tand(x);
Delta=Distance-Distance2;

% This is the plot for having dropped it at the perfect moment
Px=Speed.*axi;
Py=Altitude-.5.*g.*axi.^2;

% This is the plot for the actual line-of-sight angle drop
Ax=Delta+Speed.*axi;
Ay=Altitude-.5.*g.*axi.^2;

% Define the Cargo Plane
CargoPx=0;
CargoPy=Altitude;

CargoAx=Delta;
CargoAy=Altitude;

% Define the Island
Islandx=linspace(Distance-20,Distance+20,40);
Islandy=0;

% Define the axis parameters
xmin=min(Px);
xmax=max(Px);
ymin=min(Py);
ymax=max(Py);
axis([xmin,xmax,ymin,ymax]);

% Plot the required materials
plot(Px,Py,'g-.',Ax,Ay,'b-.',CargoPx,CargoPy,'g->',CargoAx,CargoAy,'b->',Islandx,Islandy,'y-o')

grid on

%Labels 
title('Air Drop Success Chart')
xlabel('Distance to Island')
ylabel('Altitude')

% Create a legend
legend('Perfect Drop','Actual Drop','Perfect Position','Actual Position','The Island')

if (-20<=Delta && Delta <=20)
    axes(handles.axes3)
    imshow('Flying.png')
    axes(handles.axes4)
    imshow('food.jpg')
else
    axes(handles.axes3)
    imshow('sea.jpg')
    axes(handles.axes4)
    imshow('nofood.jpg')

end
end

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global button;
button=1;