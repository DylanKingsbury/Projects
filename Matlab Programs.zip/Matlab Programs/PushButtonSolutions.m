% HW 5
% Name3534534: Dylan Kingsbury
% Purpose: To give accurate solutions for three given problems
% Copyright 2017

clc; % clear command windows
clear; % clear all variables

Solution = menu('Choose your solution!','Solution 1','Solution 2','Solution 3');
switch Solution
 case 1
         % CD BC BD DE BE AB AE EF AF
A = [5./sqrt(29) 0 0 0 0 0 0 0 0
     2./sqrt(29) 1 0 0 0 0 0 0 0
     5./sqrt(29) 0 5./sqrt(29) 0 0 0 0 0 0
     -2./sqrt(29) 0 2./sqrt(29) 1 0 0 0 0 0
     0 0 5./sqrt(29) 0 5./sqrt(29) 0 0 0 0
     0 -1 -2./sqrt(29) 0 2./sqrt(29) 1 0 0 0
     0 0 0 0 5./sqrt(29) 0 5./sqrt(29) 0 0
     0 0 0 -1 -2./sqrt(29) 0 2./sqrt(29) 1 0
     0 0 0 0 0 0 0 5./sqrt(29) 1];
B = [80
    0
    0
    0
    60
    0
    0
    0
    0];
% compute the stress in each component
X = A\B;
% determine if the member is in tension or compression
% print the solution
components= ['CD';'BC';'BD';'DE';'BE';'AB';'AE';'EF';'AF'];
fprintf('Member    Force(kN)     Type\n')
for i=1:9;
fprintf('%4s' ,components(i,:))
fprintf('%12.2f ',X(i,:))
if X(i,:)>0
    fprintf('    Compression')
else
    fprintf('      Tension')
end
fprintf('\n')
end
 case 2
% Decipher the given information
p=30;
a=25;
g=9.81;
v=input('Please input the initial velocity (m/s): ');

% determine the x, y and z components of the velocity
vx=v.*sind(p).*cosd(a);
vy=v.*sind(p).*sind(a);
vz=v.*cosd(p);

% determine the total time for five bounces to occur
tt=((2.*vz)./g)+.8.*(2.*vz./g)+(.8.^2).*(2.*vz./g)+(.8.^3).*(2.*vz./g)+(.8.^4).*(2.*vz./g)+(.8.^5).*(2.*vz./g);
tf1=((2.*vz)./g);
t1=linspace(0,((2.*vz)./g),100);

% first bounce
x=vx.*t1;
y=vy.*t1;
z=vz.*t1-.5.*g.*t1.^2;

% second bounce
t2=linspace(0,.8.*(2.*vz./g),100);
x2=vx.*tf1+.8.*vx.*t2;
y2=vy.*tf1+.8.*vy.*t2;
z2=.8.*vz.*t2-.5.*g.*t2.^2;

% third bounce
tf2=.8.*(2.*vz./g);

t3=linspace(0,(.8.^2).*(2.*vz./g),100);
x3=vx.*tf1+.8.*vx.*tf2+(.8.^2).*vx.*t3;
y3=vy.*tf1+.8.*vy.*tf2+(.8.^2).*vy.*t3;
z3=(.8.^2).*vz.*t3-.5.*g.*t3.^2;

% fourth bounce
tf3=(.8.^2).*(2.*vz./g);

t4=linspace(0,(.8.^3).*(2.*vz./g),100);
x4=vx*tf1+.8.*vx.*tf2+(.8.^2).*vx.*tf3+(.8.^3).*vx.*t4;
y4=vy*tf1+.8.*vy.*tf2+(.8.^2).*vy.*tf3+(.8.^3).*vy.*t4;
z4=(.8.^3).*vz.*t4-.5.*g.*t4.^2;

% fifth bounce
tf4=(.8.^3).*(2.*vz./g);

t5=linspace(0,(.8.^4).*(2.*vz./g),100);
x5=vx*tf1+.8.*vx.*tf2+(.8.^2).*vx.*tf3+(.8.^3).*vx.*tf4+(.8.^4).*vx.*t5;
y5=vy*tf1+.8.*vy.*tf2+(.8.^2).*vy.*tf3+(.8.^3).*vy.*tf4+(.8.^4).*vy.*t5;
z5=(.8.^4).*vz.*t5-.5.*g.*t5.^2;

% Create figure
figure;

% Create axes
axes1 = axes('ColorOrder',[0 0 1;0 0 1;0 0 1;0 0 1;0 0 1;0 0 1;0 0 1]);
hold(axes1,'on');

% Create multiple lines using matrix input to plot3
plot3(x,y,z,x2,y2,z2,x3,y3,z3,x4,y4,z4,x5,y5,z5);

% Create xlabel
xlabel('x (m)');

% Create zlabel
zlabel('z (m)');

% Create title
title('Solution 2');

% Create ylabel
ylabel('y (m)');

% creat axi limits and grids
xlim(axes1,[0 100]);
ylim(axes1,[0 150]);
zlim(axes1,[0 20]);
view(axes1,[-37.5 30]);
box(axes1,'on');
grid(axes1,'on');

% Set the remaining axes properties
set(axes1,'FontName','Cambria','FontSize',12,'FontWeight','bold','XColor',...
    [0 0 0],'YColor',[0 0 0],'ZColor',[0 0 0]);
% 3d graph
fprintf('Enjoy!\n')
 case 3
% create a 2d plot
w=linspace(0,8,100);
d=linspace(0,4,100);

% meshgrid
[x_grid, y_grid] = meshgrid(w,d);

% Z component of graph (using meshgrid to give us a applicable variable
Q=([(y_grid.*x_grid)./0.05].*[(x_grid.*y_grid)./(x_grid+2.*y_grid)].^(2./3)).*sqrt(.001);

% 3d graph
surf(x_grid,y_grid,Q)
xlabel('w(m)'),ylabel('d(m)'),zlabel('Q(m3/s)')
fprintf('Enjoy!\n')
end